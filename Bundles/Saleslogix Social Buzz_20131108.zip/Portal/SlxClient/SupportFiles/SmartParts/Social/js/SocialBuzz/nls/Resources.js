﻿define({
    root: {        
        // all the resources are defined in the global level, one folder up
    }
});