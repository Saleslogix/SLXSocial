﻿define({
    root: {
        // the resources are at the global level, makes it easier
    }
});